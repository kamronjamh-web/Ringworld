# Main spire far stand-in validation

## Result
The actual serialized replacement is 8,640 triangles, one mesh surface and one material.
All 1,024 original arm triangles are preserved exactly. The update adds 7,616 structural
triangles. The resource is 519,112 bytes. Triangle count is 91.8647% below the full asset;
this is geometry accounting, not a measured frame-time claim.

## Checks performed
- Godot 4.6.3 generated the resource from the current source GLB and loaded/instantiated it.
- Two generation runs produced byte-identical SHA-256 hashes.
- All vertices finite; no degenerate triangles; exactly one surface/material.
- Minimum distance from the axis to ANY projected triangle: **150.075364433 m**.
  This includes edge interiors and triangle interiors, not just vertex radii.
- All 248 expected triangle/solid-contact tests passed: ring-to-arm, tie-to-arm,
  tie-to-ring, tie-to-collector, clamp-to-inner-arm, and crown-to-outer-arm.
- Each of the 48 collectors connects to its adjacent inner arm/clamp structure.
- Six ring elevations: 550, 1050, 1550, 2050, 2550 and 3050 m.
- The original 8 inner + 8 outer arms keep their 22.5 degree stagger.
- Missing-mesh and invalid-angular-profile tests both failed explicitly with exit 1
  before overwriting the existing resource.
- `git diff --check` passed; only the three listed repository files changed.
- Full-detail GLB, merged scene and wrapper hashes remain identical to the base.
- Binary patch applied successfully to clean base files and reproduced all replacement hashes.

## Geometry comparison
Matched-camera native Blender renders show full-detail, previous proxy and replacement.
Independent rasterized silhouette checks in four elevated orthographic directions
(0, 22.5, 45 and 67.5 degrees) improve intersection-over-union from 75.30-82.44% to
87.57-89.87%. This metric uses triangles wholly above 100 m to exclude base/facility
geometry that intentionally fades out before the far stand-in appears.

The retained arm-only footprint is about 1,542.46 m square, unchanged. Proxy bounds are
Y 1 to 3,994 m after adding the crown (previous maximum 3,990 m). These are deliberately
simplified distant geometry, not the exact full-detail foundation/foot/tip bounds.

## Simplification and compression
Outer connector annuli use 32 angular segments (source 64), collector sectors two spans
(source four), and outer crown 64 segments (source 128). The inner crown retains its
64 source segments for clearance. Simple ties and clamps retain their source faces.
Godot import compression causes up to 0.054873 m same-profile radial spread;
bounded radius/height/angle clustering (0.075 m / 0.002 m / 0.0001 rad) restores profile
rows without changing meaningful dimensions. Missing, duplicate or invalid source
components abort the build rather than silently omitting rings.

## Verification limits
The project's Godot 4.8 dev7 .NET / .NET 10 runtime was not available. Full-project build,
in-game transition at 26-40 km, and performance benchmarks were not run. No claim is
made that the full game or pinned engine has been tested. Source geometry and resource
compatibility were checked with available Godot 4.6.3. The preview is a geometry
comparison, not a screenshot from the running Ringworld game.

## Provenance
Base commit: `793b8c7d54717042f719adda57f4eca72351e25a`.
Source GLB SHA-256: `f807a081d82f13da2188332936ed42d3812b713842ab99dfa7e98e50445ed1b7`.
Replacement resource SHA-256: `98553b051fa9856a2277a76ac857fd80b9e42e0b162cd492627b4c4e79e4a67f`.
No remote push or pull request was made.
