RINGWORLD MAIN SPIRE: FAR STAND-IN CONNECTOR RINGS UPDATE

Base repository: https://github.com/kamronjamh-web/Ringworld
Base commit: 793b8c7d54717042f719adda57f4eca72351e25a (Spires)
No remote commit, push, or pull request was made.

INSTALL: COPY THE REPLACEMENT FILES
Copy the contents of the files/ folder OVER THE MATCHING PATHS AT YOUR REPOSITORY ROOT.
Do not place the files/ folder itself inside the project. Three files are replaced:
  tools/poi/build_poi_scenes.gd
  assets/poi/main_spire/merged/meshes/MainSpire_FarProxy.res
  assets/poi/README.md
The regenerated resource is included and ready for the existing MainSpirePOI wrapper.

ALTERNATIVE: APPLY THE PATCH
From a checkout of the base commit, with no conflicting local changes:
  git apply --check /path/to/MainSpire_FarProxy_Rings.patch
  git apply /path/to/MainSpire_FarProxy_Rings.patch
Use either the copy method or the patch method, not both. The binary-inclusive patch was
applied to a clean copy of these three base files and reproduced the delivered file hashes.
If your branch has newer changes, review the patch rather than overwriting them blindly.

WHAT CHANGED
The stand-in now has six continuous outer connector rings, 48 radial ties, 48 broken
inner collector sectors, 48 feed clamps, and both open crown rings. Its original 16
staggered arm lofts are preserved exactly. The main proxy remains one surface/material,
8,640 triangles versus 106,204 in the full-detail asset (91.86% fewer triangles).
The 300 m beam path stays clear. The existing 26 km start, 2 km fade margin and no-shadow
setting are unchanged. Full-detail GLB, Blender source, merged detail, wrapper,
collisions, materials, reactor and regular-emitter resources were not changed.

REGENERATION (OPTIONAL; THE RESOURCE IS ALREADY INCLUDED)
After the source GLB is imported, run from the repository root with the project's engine:
  godot --headless --path . --script res://tools/poi/build_poi_scenes.gd -- main_spire_proxy
This new narrow mode writes only MainSpire_FarProxy.res. The regular main_spire build also
uses the corrected generator. No live tuning setting was added because this repairs a
build-time geometry omission; runtime behavior and settings are unchanged.

VALIDATION
Generated, loaded, instantiated and checked in an isolated Godot 4.6.3 project using the
repo's GLB import settings. Repeated generation produced the identical resource hash.
Independent triangle-aware bore and contact checks passed. The side-by-side preview is
a native geometry render, not a full-game capture. See VALIDATION.md for exact coverage.
The repository pins Godot 4.8 dev7 .NET (c971f93e7) and .NET 10; that complete runtime and
in-game 26-40 km transition/performance were NOT run here. No newer engine was installed.
A read-only focused check is included; after installing, run it with your pinned engine:
  godot --headless --path . --script /path/to/update/validation/verify_far_proxy.gd
