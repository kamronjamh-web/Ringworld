extends SceneTree
## Read-only focused validation. Run from the Ringworld project root with:
## godot --headless --path . --script /path/to/verify_far_proxy.gd

func _edge_radius(a: Vector2, b: Vector2) -> float:
	var dx := float(b.x) - float(a.x)
	var dy := float(b.y) - float(a.y)
	var t := clampf(-(float(a.x)*dx + float(a.y)*dy) / maxf(dx*dx + dy*dy, 1e-30), 0.0, 1.0)
	return sqrt(pow(float(a.x)+dx*t, 2) + pow(float(a.y)+dy*t, 2))

func _cross(a: Vector2, b: Vector2) -> float:
	# Scalar GDScript floats are 64-bit; Vector2.cross is 32-bit in standard builds.
	return float(a.x)*float(b.y) - float(a.y)*float(b.x)

func _triangle_radius(a3: Vector3, b3: Vector3, c3: Vector3) -> float:
	var a := Vector2(a3.x, a3.z)
	var b := Vector2(b3.x, b3.z)
	var c := Vector2(c3.x, c3.z)
	var s0 := _cross(a,b)
	var s1 := _cross(b,c)
	var s2 := _cross(c,a)
	var area := s0+s1+s2
	if absf(area) > 1e-10 and ((s0 >= 0.0 and s1 >= 0.0 and s2 >= 0.0) or (s0 <= 0.0 and s1 <= 0.0 and s2 <= 0.0)):
		return 0.0
	return minf(_edge_radius(a,b), minf(_edge_radius(b,c), _edge_radius(c,a)))

func _init() -> void:
	var mesh := load("res://assets/poi/main_spire/merged/meshes/MainSpire_FarProxy.res") as ArrayMesh
	if mesh == null:
		push_error("MainSpire_FarProxy.res could not be loaded")
		quit(1)
		return
	var faces := mesh.get_faces()
	var minimum := INF
	var valid := mesh.get_surface_count() == 1 and faces.size() == 8640 * 3
	valid = valid and mesh.surface_get_material(0) != null
	for i in range(0, faces.size(), 3):
		var a := faces[i]
		var b := faces[i+1]
		var c := faces[i+2]
		valid = valid and a.is_finite() and b.is_finite() and c.is_finite()
		valid = valid and (b-a).cross(c-a).length_squared() > 0.000001
		minimum = minf(minimum, _triangle_radius(a,b,c))
	valid = valid and minimum >= 150.0
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	root.add_child(instance)
	print("MAIN_SPIRE_FAR_PROXY_QA ", "PASS" if valid else "FAIL", " triangles=", faces.size()/3, " surfaces=", mesh.get_surface_count(), " min_triangle_radius_m=", minimum)
	instance.free()
	quit(0 if valid else 1)
